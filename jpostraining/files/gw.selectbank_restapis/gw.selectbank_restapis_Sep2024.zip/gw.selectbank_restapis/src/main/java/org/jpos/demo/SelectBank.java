package org.jpos.demo;

import org.jpos.core.Configurable;
import org.jpos.core.Configuration;
import org.jpos.core.ConfigurationException;
import org.jpos.iso.ISOMsg;
import org.jpos.rc.CMF;
import org.jpos.transaction.*;
import org.jpos.util.Caller;


import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class SelectBank implements TransactionParticipant, Configurable {

    private Map<String,String> firstDigitMap = new HashMap<>();
    private String defaultDest;


    @Override
    public int prepare(long id, Serializable context) {
        Context ctx= (Context) context;
        ISOMsg m = ctx.get("REQUEST");

        String pan = m.getString(2);
        if (pan == null) {
            return ctx.getResult().fail(CMF.CARD_VERIFICATION_DATA_FAILED,
                                        Caller.info(),
                                       "PAN was null").FAIL();
        }

        String panFirst = pan.substring(0, 1);
        String dst = firstDigitMap.get(panFirst);
        if (dst != null)
            ctx.put("DESTINATION", dst);
        else
            ctx.put("DESTINATION", defaultDest);

        return PREPARED | NO_JOIN;
    }

    @Override
    public void setConfiguration(Configuration cfg) throws ConfigurationException {
        String [] firstDigits = cfg.getAll("first-digit");

        if (firstDigits != null)
            for (String fd :firstDigits) {
                String []splits= fd.split(" ");
                firstDigitMap.put(splits[0], splits[1]);
            }
        defaultDest = cfg.get("default-dest", "");
    }

}
