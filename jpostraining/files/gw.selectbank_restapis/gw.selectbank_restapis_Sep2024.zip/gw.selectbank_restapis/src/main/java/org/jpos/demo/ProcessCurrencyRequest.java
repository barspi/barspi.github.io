package org.jpos.demo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.jpos.transaction.Context;
import org.jpos.transaction.TransactionParticipant;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Map;

import static org.jpos.qrest.Constants.JSON_REQUEST;

public class ProcessCurrencyRequest implements TransactionParticipant
{
    ObjectMapper mapper = new ObjectMapper()
          .enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)
          .enable(SerializationFeature.INDENT_OUTPUT)
          .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
          .configure(DeserializationFeature.FAIL_ON_INVALID_SUBTYPE, false)
          .setSerializationInclusion(JsonInclude.Include.NON_EMPTY);

    @Override
    public int prepare(long id, Serializable context) {
        Context ctx = (Context) context;

        String jsonRequest = ctx.get("JSON_REQUEST");

        try {
            Map<String,Object> m= mapper.readValue(jsonRequest, Map.class);
            BigDecimal amount = (BigDecimal) m.get("amount");
            String from = (String)m.get("from");
            String to = (String)m.get("to");

            ctx.put("AMOUNT", amount);
            ctx.put("FROM_CURRENCY", from.toLowerCase());
            ctx.put("TO_CURRENCY", to.toLowerCase());

            // ctx.put("HTTP_URL",
            //         "https://cdn.jsdelivr.net/gh/fawazahmed0/currency-api@1/latest/currencies/"+from.toLowerCase()+"/"+to.toLowerCase()+".json");
            ctx.put("HTTP_URL",
                    "https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/"+from.toLowerCase()+".json");


            ctx.put("HTTP_METHOD", "GET");


        } catch (Exception e) {
            ctx.log(e);
            return ABORTED;
        }

        return PREPARED | NO_JOIN;
    }

}
