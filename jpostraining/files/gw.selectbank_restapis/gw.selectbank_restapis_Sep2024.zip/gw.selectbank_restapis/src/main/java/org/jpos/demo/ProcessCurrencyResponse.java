package org.jpos.demo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import io.netty.handler.codec.http.HttpResponseStatus;
import org.jpos.qrest.Response;
import org.jpos.transaction.Context;
import org.jpos.transaction.TransactionParticipant;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import static org.jpos.qrest.Constants.JSON_REQUEST;
import static org.jpos.qrest.Constants.RESPONSE;

public class ProcessCurrencyResponse implements TransactionParticipant
{
    ObjectMapper mapper = new ObjectMapper()
          .enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)
          .enable(SerializationFeature.INDENT_OUTPUT)
          .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
          .configure(DeserializationFeature.FAIL_ON_INVALID_SUBTYPE, false)
          .setSerializationInclusion(JsonInclude.Include.NON_EMPTY);

    @Override
    @SuppressWarnings("unchecked")
    public int prepare(long id, Serializable context) {
        Context ctx = (Context) context;

        String httpResponse = ctx.get("HTTP_RESPONSE");
//        int  httpStatus = ctx.get("HTTP_STATUS");

        try {
            Map<String,Object> m= mapper.readValue(httpResponse, Map.class);
            BigDecimal amount = ctx.get("AMOUNT");
            String fromCurrency = ctx.get("FROM_CURRENCY");
            String toCurrency = ctx.get("TO_CURRENCY");

            Map currencies = (Map) m.get(fromCurrency);
            BigDecimal rate= (BigDecimal) currencies.get(toCurrency);

            BigDecimal result = amount.multiply(rate);

            Map<String,Object> resultMap = new HashMap<>();
            resultMap.put("result", result);

            Response r = new Response(HttpResponseStatus.OK, resultMap);
            ctx.put(RESPONSE, r);

        } catch (Exception e) {
            ctx.log(e);
            return ABORTED;
        }

        return PREPARED | NO_JOIN;
    }

}
